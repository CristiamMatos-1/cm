## 1. Desenho da Arquitetura
```mermaid
graph TD
    subgraph Frontend
        A["Navegador (Mobile/Desktop)"]
        B["HTML5, CSS3, JS (Tailwind/Bootstrap)"]
    end
    subgraph Backend - PHP MVC
        C["Rotas Amigáveis"]
        D["Controllers"]
        E["Models (PDO)"]
        F["Views"]
    end
    subgraph Dados
        G["MySQL (InnoDB)"]
    end
    subgraph Serviços Externos
        H["Google Gemini API"]
    end
    A <--> B
    B <--> C
    C --> D
    D <--> E
    D <--> F
    E <--> G
    D <--> H
```

## 2. Descrição Tecnológica
- **Frontend**: HTML5, CSS3, Vanilla JavaScript, Tailwind CSS (ou Bootstrap). Abordagem Mobile-First.
- **Backend**: PHP 8+ (Orientação a Objetos, PSR-4, PSR-12).
- **Arquitetura**: Padrão MVC com roteador customizado ou simples.
- **Banco de Dados**: MySQL Relacional (InnoDB, chaves estrangeiras, proteção contra SQL Injection com PDO).

## 3. Definições de Rotas
| Rota | Propósito |
|-------|---------|
| `/login` | Autenticação de usuários (CPF/CNPJ) |
| `/register` | Cadastro de novos clientes |
| `/dashboard` | Painel de controle (varia por perfil) |
| `/tickets` | Listagem e gestão de chamados |
| `/tickets/create` | Abertura de novo chamado |
| `/tickets/view/{id}` | Visualização de um chamado específico e upload de mídias |
| `/api/gemini/analyze` | Rota para comunicação com a API do Gemini |
| `/contracts` | Gestão de contratos e SLAs |

## 4. Definições de API (Integração Gemini)
- `POST /api/gemini/analyze`: Recebe descrição do problema, retorna sugestões em JSON.

## 5. Diagrama de Arquitetura do Servidor
```mermaid
graph LR
    A["Router"] --> B["TicketController"]
    B --> C["TicketModel"]
    B --> D["GeminiService"]
    C --> E["Database (PDO)"]
    B --> F["TicketView"]
```

## 6. Modelo de Dados
### 6.1 Definição do Modelo de Dados
```mermaid
erDiagram
    USERS {
        int id PK
        varchar cpf_cnpj UK
        varchar nome
        varchar email
        varchar telefone
        varchar senha
        enum perfil "admin, tecnico, cliente"
    }
    TICKETS {
        int id PK
        int cliente_id FK
        int tecnico_id FK
        varchar tipo_servico
        text descricao
        enum atendimento "remoto, presencial"
        enum status "aberto, andamento, finalizado"
        text relatorio_final
    }
    CONTRACTS {
        int id PK
        int cliente_id FK
        decimal valor_mensal
        date data_validade
        int prazo_renovacao_anos
        text conteudo_sla
    }
    ASSETS {
        int id PK
        int cliente_id FK
        varchar nome_equipamento
        varchar numero_serie
    }
    USERS ||--o{ TICKETS : "abre/atende"
    USERS ||--o{ CONTRACTS : "possui"
    USERS ||--o{ ASSETS : "possui"
```

### 6.2 Linguagem de Definição de Dados (DDL)
A estrutura exata será fornecida no arquivo `database.sql` durante a fase de desenvolvimento, com regras de restrição de integridade referencial.