## 1. Visão Geral do Produto
Sistema de Gestão de Serviços de TI e Assistência Técnica (ITSM/ERP) para gerenciar chamados, contratos, ativos e integração com IA.
- Atender demandas de empresas prestadoras de serviço de TI (helpdesk, manutenção de equipamentos e sistemas).
- Centralizar o relacionamento com clientes, controle de contratos/notas fiscais e uso de inteligência artificial para auxiliar técnicos.

## 2. Funcionalidades Principais

### 2.1 Perfis de Usuário
| Perfil | Método de Registro | Permissões Principais |
|------|---------------------|------------------|
| Administrador | Cadastro interno/Sistema | Acesso total: gestão corporativa, contratos, notas fiscais, fornecedores, chamados, usuários |
| Técnico | Cadastro interno/Sistema | Gestão e execução de chamados, uso do Consultor Gemini, upload de mídias, relatórios |
| Cliente | Tela de Login (CPF/CNPJ) | Abertura/acompanhamento de chamados, visualização de contratos/notas fiscais, visualização de patrimônio |

### 2.2 Módulos do Sistema
1. **Autenticação**: Login exclusivo por CPF/CNPJ. Cadastro de novos clientes com validação.
2. **Dashboards**: Visões específicas (KPIs) para clientes e para equipe técnica/admin.
3. **Gestão de Chamados**: Abertura, triagem (Remoto/Presencial), upload nativo de mídia, encerramento com relatório.
4. **Contratos e Notas Fiscais**: Editor de contratos SLA, upload de NFs (PDF/XML) pelo admin e download pelo cliente.
5. **Configurações e Ativos**: Dados da empresa, gestão de patrimônio e fornecedores.
6. **Integração IA**: Consultor Gemini para análise de problemas de chamados.

### 2.3 Detalhamento de Páginas
| Nome da Página | Nome do Módulo | Descrição da Funcionalidade |
|-----------|-------------|---------------------|
| Login/Cadastro | Autenticação | Acesso via CPF/CNPJ. Formulário de cadastro de cliente (Nome, Email, Telefone, Senha). |
| Dashboard Cliente | Dashboards | Resumo de chamados abertos, contratos ativos, faturas para download e equipamentos. |
| Dashboard Admin/Técnico | Dashboards | KPIs de chamados, relatórios de serviços, atalhos rápidos. |
| Lista de Chamados | Gestão de Chamados | Filtros por status, cliente e técnico. Criação de novos chamados. |
| Detalhe do Chamado | Gestão de Chamados | Chat/Histórico, botão "Analisar com IA", envio de fotos/vídeos (mobile-friendly), encerramento. |
| Contratos e NFs | Contratos e Notas | Editor de SLA, controle de vigência, área de upload/download de faturas. |
| Configurações | Ativos e Empresa | Cadastro da empresa prestadora, gestão de patrimônio e controle de fornecedores. |

## 3. Processo Principal
O cliente se cadastra/loga via CPF/CNPJ e abre um chamado. O técnico tria, utiliza a IA para auxílio no diagnóstico, executa o serviço com upload de evidências e encerra o chamado gerando um relatório. O admin gerencia contratos, emite notas e controla os ativos.
```mermaid
graph TD
    A["Cliente Loga (CPF/CNPJ)"] --> B["Abre Chamado"]
    B --> C["Técnico Recebe e Tria"]
    C --> D["Analisar com IA (Gemini)"]
    D --> E["Execução e Upload de Mídia"]
    E --> F["Encerramento e Relatório"]
    G["Admin"] --> H["Gere Contratos e Notas"]
    G --> I["Gere Ativos e Fornecedores"]
```

## 4. Design de Interface de Usuário
### 4.1 Estilo de Design
- **Cores Primárias e Secundárias**: Tons de azul corporativo (confiança), cinza claro (fundo/cards) e branco.
- **Estilo de Botões**: Bordas levemente arredondadas, flat design com hover states responsivos.
- **Fontes e Tamanhos**: Fontes modernas e legíveis (ex: Inter ou Roboto, adaptado para Tailwind/Bootstrap), tamanhos responsivos.
- **Estilo de Layout**: Dashboard com menu lateral (sidebar) e área de conteúdo baseada em cards.
- **Sugestões de Ícones**: Minimalistas (ex: FontAwesome ou Heroicons).

### 4.2 Visão Geral do Design das Páginas
| Nome da Página | Nome do Módulo | Elementos de UI |
|-----------|-------------|-------------|
| Dashboard | Dashboards | Sidebar expansível, Grid de Cards (KPIs), Tabelas de listagem rápida, Cores suaves. |
| Detalhe Chamado | Gestão de Chamados | Timeline de interações, Botão de destaque para IA, Galeria de mídias otimizada para mobile. |

### 4.3 Responsividade
- **Mobile-First**: Otimizado para smartphones, especialmente fluxos de câmera/upload de mídia para chamados e menus colapsáveis.