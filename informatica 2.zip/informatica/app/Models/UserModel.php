<?php
namespace app\Models;

use PDO;
use Exception;

class UserModel extends Model {
    
    /**
     * Busca um usuário pelo CPF ou CNPJ
     */
    public function getUserByCpfCnpj($cpf_cnpj) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE cpf_cnpj = :cpf_cnpj LIMIT 1");
        $stmt->bindParam(':cpf_cnpj', $cpf_cnpj);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * Busca todos os clientes
     */
    public function getAllClients() {
        $stmt = $this->db->prepare("SELECT id, nome, cpf_cnpj, email FROM users WHERE perfil = 'cliente' ORDER BY nome ASC");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Cria um novo usuário (Cliente)
     */
    public function createUser($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO users (nome, cpf_cnpj, email, telefone, senha, perfil) 
                VALUES (:nome, :cpf_cnpj, :email, :telefone, :senha, 'cliente')
            ");
            
            $stmt->bindParam(':nome', $data['nome']);
            $stmt->bindParam(':cpf_cnpj', $data['cpf_cnpj']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':telefone', $data['telefone']);
            $stmt->bindParam(':senha', $data['senha_hash']);
            
            return $stmt->execute();
        } catch (Exception $e) {
            // Em produção, registre o erro no log
            return false;
        }
    }
}
