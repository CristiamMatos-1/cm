<?php
namespace app\Controllers;

use app\Models\ChamadoModel;
use app\Models\FinanceiroModel;
use app\Models\UserModel;
use app\Models\ConfigModel;
use app\Helpers\Security;
use app\Helpers\UploadHelper;

class AdminController extends Controller {

    public function __construct() {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
            $this->redirect('/auth');
        }
    }

    public function index() {
        $chamadoModel = new ChamadoModel();
        $totalChamados = $chamadoModel->countAll();

        $this->view('dashboard/admin', [
            'title' => 'Visão Geral - Admin',
            'totalChamados' => $totalChamados
        ]);
    }

    // ==========================================
    // MÓDULO FINANCEIRO (CONTRATOS E NOTAS)
    // ==========================================

    public function financeiro() {
        $financeiroModel = new FinanceiroModel();
        
        $this->view('admin/financeiro_list', [
            'title' => 'Gestão de Contratos e Notas',
            'contratos' => $financeiroModel->getAllContratos(),
            'notas' => $financeiroModel->getAllNotas()
        ]);
    }

    public function novoContrato() {
        $userModel = new UserModel();
        $clientes = $userModel->getAllClients();

        $this->view('admin/novo_contrato', [
            'title' => 'Criar Novo Contrato',
            'clientes' => $clientes,
            'csrf_token' => Security::generateCsrfToken()
        ]);
    }

    public function salvarContrato() {
        $this->requirePost();

        $dados = [
            'cliente_id' => isset($_POST['cliente_id']) ? $_POST['cliente_id'] : '',
            'valor_mensal' => str_replace(',', '.', isset($_POST['valor_mensal']) ? $_POST['valor_mensal'] : '0'),
            'data_inicio' => isset($_POST['data_inicio']) ? $_POST['data_inicio'] : '',
            'data_validade' => isset($_POST['data_validade']) ? $_POST['data_validade'] : '',
            'prazo_renovacao_anos' => (int)(isset($_POST['prazo_renovacao_anos']) ? $_POST['prazo_renovacao_anos'] : 1),
            'conteudo_sla' => Security::sanitizeInput(isset($_POST['conteudo_sla']) ? $_POST['conteudo_sla'] : '')
        ];

        if (!empty($dados['cliente_id']) && !empty($dados['valor_mensal'])) {
            $financeiroModel = new FinanceiroModel();
            $financeiroModel->createContrato($dados);
        }

        $this->redirect('/admin/financeiro');
    }

    public function novaNota() {
        $userModel = new UserModel();
        $financeiroModel = new FinanceiroModel();

        $this->view('admin/nova_nota', [
            'title' => 'Emitir/Anexar Nota Fiscal',
            'clientes' => $userModel->getAllClients(),
            'contratos' => $financeiroModel->getAllContratos(),
            'csrf_token' => Security::generateCsrfToken()
        ]);
    }

    public function salvarNota() {
        $this->requirePost();

        $dados = [
            'cliente_id' => isset($_POST['cliente_id']) ? $_POST['cliente_id'] : '',
            'contrato_id' => !empty($_POST['contrato_id']) ? $_POST['contrato_id'] : null,
            'numero_nf' => Security::sanitizeInput(isset($_POST['numero_nf']) ? $_POST['numero_nf'] : ''),
            'valor' => str_replace(',', '.', isset($_POST['valor']) ? $_POST['valor'] : '0'),
            'data_emissao' => isset($_POST['data_emissao']) ? $_POST['data_emissao'] : ''
        ];

        if (empty($dados['cliente_id']) || empty($dados['numero_nf']) || empty($_FILES['arquivo_nf']['name'])) {
            $this->redirect('/admin/novaNota');
            return;
        }

        $upload = UploadHelper::processInvoiceUpload($_FILES['arquivo_nf']);

        if (isset($upload['success'])) {
            $dados['arquivo_url'] = $upload['success'];
            $financeiroModel = new FinanceiroModel();
            $financeiroModel->createNotaFiscal($dados);
            $this->redirect('/admin/financeiro');
        } else {
            // Em produção, exibir erro na tela
            $this->redirect('/admin/novaNota');
        }
    }

    // ==========================================
    // MÓDULO 5: CONFIGURAÇÕES E ATIVOS
    // ==========================================

    public function configuracoes() {
        $configModel = new ConfigModel();
        
        $this->view('admin/configuracoes', [
            'title' => 'Configurações Globais',
            'empresa' => $configModel->getCompanyInfo(),
            'fornecedores' => $configModel->getAllSuppliers(),
            'ativos' => $configModel->getAllAssets(),
            'csrf_token' => Security::generateCsrfToken()
        ]);
    }

    public function salvarEmpresa() {
        $this->requirePost();
        
        $dados = [
            'razao_social' => Security::sanitizeInput(isset($_POST['razao_social']) ? $_POST['razao_social'] : ''),
            'cnpj' => Security::sanitizeInput(isset($_POST['cnpj']) ? $_POST['cnpj'] : ''),
            'matriz_filial' => isset($_POST['matriz_filial']) ? $_POST['matriz_filial'] : 'matriz'
        ];

        $configModel = new ConfigModel();
        $configModel->updateCompany($dados);

        $this->redirect('/admin/configuracoes');
    }

    public function salvarFornecedor() {
        $this->requirePost();
        
        $dados = [
            'nome' => Security::sanitizeInput(isset($_POST['nome']) ? $_POST['nome'] : ''),
            'cnpj' => Security::sanitizeInput(isset($_POST['cnpj']) ? $_POST['cnpj'] : ''),
            'telefone' => Security::sanitizeInput(isset($_POST['telefone']) ? $_POST['telefone'] : ''),
            'email' => Security::sanitizeInput(isset($_POST['email']) ? $_POST['email'] : '')
        ];

        $configModel = new ConfigModel();
        $configModel->createSupplier($dados);

        $this->redirect('/admin/configuracoes');
    }

    public function novoAtivo() {
        $userModel = new UserModel();
        $configModel = new ConfigModel();

        $this->view('admin/novo_ativo', [
            'title' => 'Cadastrar Equipamento',
            'clientes' => $userModel->getAllClients(),
            'fornecedores' => $configModel->getAllSuppliers(),
            'csrf_token' => Security::generateCsrfToken()
        ]);
    }

    public function salvarAtivo() {
        $this->requirePost();

        $dados = [
            'cliente_id' => !empty($_POST['cliente_id']) ? $_POST['cliente_id'] : null,
            'fornecedor_id' => !empty($_POST['fornecedor_id']) ? $_POST['fornecedor_id'] : null,
            'nome_equipamento' => Security::sanitizeInput(isset($_POST['nome_equipamento']) ? $_POST['nome_equipamento'] : ''),
            'numero_serie' => Security::sanitizeInput(isset($_POST['numero_serie']) ? $_POST['numero_serie'] : ''),
            'data_compra' => isset($_POST['data_compra']) ? $_POST['data_compra'] : null,
            'garantia_meses' => (int)(isset($_POST['garantia_meses']) ? $_POST['garantia_meses'] : 12)
        ];

        if (!empty($dados['nome_equipamento'])) {
            $configModel = new ConfigModel();
            $configModel->createAsset($dados);
        }

        $this->redirect('/admin/configuracoes');
    }
}
