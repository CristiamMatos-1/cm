<?php require_once APP_PATH . '/Views/layout/header.php'; ?>

<div class="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
    <h2 class="text-2xl font-bold text-gray-800">Gestão de Usuários e Permissões</h2>
    <a href="<?= BASE_URL ?>/admin/novoUsuario" class="bg-indigo-600 text-white px-4 py-2 rounded shadow hover:bg-indigo-700 transition-colors text-sm font-medium">
        <i class="fas fa-user-plus mr-1"></i> Criar Novo Usuário
    </a>
</div>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contato</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Perfil</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Permissões</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
                <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td class="px-6 py-4">
                        <div class="font-medium text-gray-900"><?= htmlspecialchars($u['nome']) ?></div>
                        <div class="text-sm text-gray-500 font-mono"><?= htmlspecialchars($u['cpf_cnpj']) ?></div>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-600">
                        <div><?= htmlspecialchars($u['email']) ?></div>
                        <div><?= htmlspecialchars($u['telefone']) ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <?php
                            $cor = 'bg-gray-100 text-gray-800';
                            if ($u['perfil'] === 'admin') $cor = 'bg-red-100 text-red-800';
                            if ($u['perfil'] === 'tecnico') $cor = 'bg-blue-100 text-blue-800';
                            if ($u['perfil'] === 'cliente') $cor = 'bg-green-100 text-green-800';
                        ?>
                        <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?= $cor ?>">
                            <?= strtoupper($u['perfil']) ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm text-gray-600">
                        <form action="<?= BASE_URL ?>/admin/salvarPermissoes" method="POST" class="flex flex-col space-y-2">
                            <input type="hidden" name="csrf_token" value="<?= $csrf_token ?? '' ?>">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            
                            <?php $perms = json_decode($u['permissoes'] ?? '[]', true) ?: []; ?>
                            
                            <label class="inline-flex items-center">
                                <input type="checkbox" name="permissoes[]" value="abrir_chamado_admin" <?= in_array('abrir_chamado_admin', $perms) ? 'checked' : '' ?> class="form-checkbox h-4 w-4 text-indigo-600">
                                <span class="ml-2 text-xs">Pode abrir chamados (Admin)</span>
                            </label>
                            <label class="inline-flex items-center">
                                <input type="checkbox" name="permissoes[]" value="criar_orcamento" <?= in_array('criar_orcamento', $perms) ? 'checked' : '' ?> class="form-checkbox h-4 w-4 text-indigo-600">
                                <span class="ml-2 text-xs">Pode gerenciar Orçamentos</span>
                            </label>
                            <label class="inline-flex items-center">
                                <input type="checkbox" name="permissoes[]" value="gerar_relatorios" <?= in_array('gerar_relatorios', $perms) ? 'checked' : '' ?> class="form-checkbox h-4 w-4 text-indigo-600">
                                <span class="ml-2 text-xs">Pode emitir Relatórios</span>
                            </label>

                            <button type="submit" class="mt-2 text-xs bg-gray-200 hover:bg-gray-300 text-gray-800 py-1 px-2 rounded w-fit">Salvar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once APP_PATH . '/Views/layout/footer.php'; ?>