<?php require_once APP_PATH . '/Views/layout/header.php'; ?>

<div class="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
    <h2 class="text-2xl font-bold text-gray-800">Orçamentos Enviados</h2>
    <a href="<?= BASE_URL ?>/admin/novoOrcamento" class="bg-indigo-600 text-white px-4 py-2 rounded shadow hover:bg-indigo-700 transition-colors text-sm font-medium">
        <i class="fas fa-plus mr-1"></i> Criar Orçamento
    </a>
</div>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Título / Ref.</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
                <?php if (empty($orcamentos)): ?>
                    <tr><td colspan="5" class="px-6 py-8 text-center text-gray-500">Nenhum orçamento gerado.</td></tr>
                <?php else: ?>
                    <?php foreach ($orcamentos as $o): ?>
                    <tr>
                        <td class="px-6 py-4">
                            <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($o['titulo']) ?></div>
                            <?php if ($o['ticket_id']): ?>
                                <div class="text-xs text-gray-500">Ref. Chamado #<?= $o['ticket_id'] ?> (<?= htmlspecialchars($o['tipo_servico']) ?>)</div>
                            <?php endif; ?>
                            <div class="text-xs text-gray-400 mt-1 italic"><?= date('d/m/Y', strtotime($o['created_at'])) ?></div>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600"><?= htmlspecialchars($o['cliente_nome']) ?></td>
                        <td class="px-6 py-4 text-sm font-semibold text-gray-800">R$ <?= number_format($o['valor'], 2, ',', '.') ?></td>
                        <td class="px-6 py-4">
                            <?php
                                $cor = 'bg-yellow-100 text-yellow-800';
                                if ($o['status'] === 'aprovado') $cor = 'bg-green-100 text-green-800';
                                if ($o['status'] === 'rejeitado') $cor = 'bg-red-100 text-red-800';
                                if ($o['status'] === 'executado') $cor = 'bg-blue-100 text-blue-800';
                            ?>
                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?= $cor ?>">
                                <?= strtoupper($o['status']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-600">
                            <?php if ($o['status'] === 'aprovado'): ?>
                                <form action="<?= BASE_URL ?>/admin/alterarStatusOrcamento/<?= $o['id'] ?>" method="POST" class="inline">
                                    <input type="hidden" name="status" value="executado">
                                    <button type="submit" class="text-blue-600 hover:text-blue-900 font-medium">Marcar como Executado</button>
                                </form>
                            <?php else: ?>
                                <span class="text-gray-400">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once APP_PATH . '/Views/layout/footer.php'; ?>