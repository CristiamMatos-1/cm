<?php
namespace app\Models;

class OrcamentoModel extends Model {

    public function getAllBudgets() {
        $stmt = $this->db->query("
            SELECT b.*, u.nome as cliente_nome, t.tipo_servico 
            FROM budgets b
            JOIN users u ON b.cliente_id = u.id
            LEFT JOIN tickets t ON b.ticket_id = t.id
            ORDER BY b.created_at DESC
        ");
        return $stmt->fetchAll();
    }

    public function getBudgetsByClient($cliente_id) {
        $stmt = $this->db->prepare("
            SELECT b.*, t.tipo_servico 
            FROM budgets b
            LEFT JOIN tickets t ON b.ticket_id = t.id
            WHERE b.cliente_id = :cliente_id 
            ORDER BY b.created_at DESC
        ");
        $stmt->bindParam(':cliente_id', $cliente_id);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function createBudget($data) {
        $stmt = $this->db->prepare("
            INSERT INTO budgets (cliente_id, ticket_id, titulo, descricao, valor, status) 
            VALUES (:cliente_id, :ticket_id, :titulo, :descricao, :valor, 'pendente')
        ");
        
        $stmt->bindParam(':cliente_id', $data['cliente_id']);
        $stmt->bindParam(':ticket_id', $data['ticket_id']);
        $stmt->bindParam(':titulo', $data['titulo']);
        $stmt->bindParam(':descricao', $data['descricao']);
        $stmt->bindParam(':valor', $data['valor']);
        
        return $stmt->execute();
    }

    public function updateStatus($id, $status) {
        $stmt = $this->db->prepare("UPDATE budgets SET status = :status WHERE id = :id");
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
