<?php
namespace app\Models;

use PDO;
use Exception;

class UserModel extends Model {
    
    /**
     * Busca um usuário pelo CPF ou CNPJ
     */
    public function getUserByCpfCnpj($cpf_cnpj) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE cpf_cnpj = :cpf_cnpj LIMIT 1");
        $stmt->bindParam(':cpf_cnpj', $cpf_cnpj);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * Cria um novo usuário diretamente pelo Admin
     */
    public function createUserByAdmin($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO users (nome, cpf_cnpj, email, telefone, senha, perfil, permissoes) 
                VALUES (:nome, :cpf_cnpj, :email, :telefone, :senha, :perfil, :permissoes)
            ");
            
            $stmt->bindParam(':nome', $data['nome']);
            $stmt->bindParam(':cpf_cnpj', $data['cpf_cnpj']);
            $stmt->bindParam(':email', $data['email']);
            $stmt->bindParam(':telefone', $data['telefone']);
            $stmt->bindParam(':senha', $data['senha_hash']);
            $stmt->bindParam(':perfil', $data['perfil']);
            $stmt->bindParam(':permissoes', $data['permissoes']);
            
            return $stmt->execute();
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Atualiza as permissões granulares de um usuário
     */
    public function updateUserPermissions($id, $permissoes) {
        $stmt = $this->db->prepare("UPDATE users SET permissoes = :permissoes WHERE id = :id");
        $stmt->bindParam(':permissoes', $permissoes);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}
